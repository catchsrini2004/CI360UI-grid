import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DatastoreService {

  constructor() { }

   storeData = [

    {   id: "bc1",
      name: "Germany",
      externalCode: "BC10011",
      description: "Business context for German customers",
      lastModifiedDate: "Mon Mar 19 14:00:00 EST 2019",
      LastPublishedBy: null,
      selected :false
    },
     {   id: "bc2",
      name: "Brazil",
      externalCode: "BC10012",
      description: "Business context for Brazilian customers",
      lastModifiedDate: "Fri Mar 23 11:00:00 EST 2018",
      LastPublishedBy: null,
      selected :false
    },
     {   id: "bc3",
      name: "BC info map not editable",
      externalCode: "BC10013",
      description: "Business context for Canadian customers",
      lastModifiedDate: "Wed Mar 21 09:00:00 EST 2017",
      LastPublishedBy: null,
      selected :false
    },
     {   id: "bc4",
      name: "BC info map not editable",
      externalCode: "BC10014",
      description: "Business context for Romanian customers",
      lastModifiedDate: "Wed Mar 27 10:00:00 EST 2019",
      LastPublishedBy: null,
      selected :false
    } 
    ]
    
}
