import { Component, OnInit } from '@angular/core';
import { DatastoreService } from '../datastore.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  constructor(private ds :  DatastoreService) { }

  dataColl = [];
  selCount= 0;

  ngOnInit(): void {
    this.dataColl = this.ds.storeData;
  }

  
  selAll(val) {
    this.dataColl.forEach((item) => {
      item.selected = val;
    });
  }

  selItem(obj, val) { debugger;
    this.selCount = 0;
    this.dataColl.forEach((item) => {

      if (item.externalCode == obj.externalCode ) {
        item.selected = val;
      }
       
    });

    this.dataColl.forEach((item) => {

      if ( item.selected )
      {
        this.selCount++;
      }
    });

  }

  filterData(key) {
 
    let coll = this.dataColl;

    if (key.length >= 3) {

    this.dataColl = coll.filter((data) => {

     return (data.name.toString().toLowerCase().includes(key.toLowerCase()) || 
     data.lastModifiedDate.toString().toLowerCase().includes(key.toLowerCase()) ||
     data.description.toString().toLowerCase().includes(key.toLowerCase()) || 
     data.externalCode.toString().toLowerCase().includes(key.toLowerCase()))

    })
  }else {
    this.dataColl = this.ds.storeData;
  }

  }

}
